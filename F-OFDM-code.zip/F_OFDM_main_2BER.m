%% different windows comparison
SNR=-5:3:16;
rep = 100;
BER = zeros(size(SNR,2),rep); %ber是一个8*10000的数组，每一列是一次实验出来的ber
BER2 = zeros(size(SNR,2),rep);
BER3 = zeros(size(SNR,2),rep);
BER4 = zeros(size(SNR,2),rep);
BER5 = zeros(size(SNR,2),rep);
BER6 = zeros(size(SNR,2),rep);
for j = 1:rep
    waitbar(j/rep); 
    [k1,m1] = F_OFDM_BCH_2BER(16,2,1,16,2.8,2048,0.01);
    BER(:,j) = k1'; %OFDM函数做出来的是一个1*8的数组
    BER2(:,j) = m1';
    [k2,m2] = F_OFDM_BCH_2BER(16,2,2,16,2.8,2048,0.01);
    BER3(:,j) = k2'; %OFDM函数做出来的是一个1*8的数组
    BER4(:,j) = m2';
    [k3,m3] = F_OFDM_BCH_2BER(16,2,3,16,2.8,2048,0.01);
    BER5(:,j) = k3'; %OFDM函数做出来的是一个1*8的数组
    BER6(:,j) = m3';
end

semilogy(SNR,mean(BER,2),'b-*');
hold on;
semilogy(SNR,mean(BER2,2),'b-o');
hold on;
semilogy(SNR,mean(BER3,2),'r-*');
hold on;
semilogy(SNR,mean(BER4,2),'r-o');
hold on;
semilogy(SNR,mean(BER5,2),'k-*');
hold on;
semilogy(SNR,mean(BER6,2),'k-o');
xlabel('SNR');
ylabel('BER');
title('BER of 16QAM OFDM symbols under different windows after rayleigh channel');
legend('hanning-Subband1','hanning-Subband2','hamming-Subband1','hamming-Subband2','kaiser(beta=16)-Subband1','kaiser(beta=16)-Subband2');
%% different channels comparison
SNR=-5:3:16;
rep = 100;
BER = zeros(size(SNR,2),rep); %ber是一个8*10000的数组，每一列是一次实验出来的ber
BER2 = zeros(size(SNR,2),rep);
BER3 = zeros(size(SNR,2),rep);
BER4 = zeros(size(SNR,2),rep);
BER5 = zeros(size(SNR,2),rep);
BER6 = zeros(size(SNR,2),rep);
for j = 1:rep
    waitbar(j/rep); 
    [k1,m1] = F_OFDM_BCH_2BER(16,1,1,16,2.8,2048,0.01);
    BER(:,j) = k1'; %OFDM函数做出来的是一个1*8的数组
    BER2(:,j) = m1';
    [k2,m2] = F_OFDM_BCH_2BER(16,2,1,16,2.8,2048,0.01);
    BER3(:,j) = k2'; %OFDM函数做出来的是一个1*8的数组
    BER4(:,j) = m2';
    [k3,m3] = F_OFDM_BCH_2BER(16,3,1,16,2.8,2048,0.01);
    BER5(:,j) = k3'; %OFDM函数做出来的是一个1*8的数组
    BER6(:,j) = m3';
end

semilogy(SNR,mean(BER,2),'b-*');
hold on;
semilogy(SNR,mean(BER2,2),'b-o');
hold on;
semilogy(SNR,mean(BER3,2),'r-*');
hold on;
semilogy(SNR,mean(BER4,2),'r-o');
hold on;
semilogy(SNR,mean(BER5,2),'k-*');
hold on;
semilogy(SNR,mean(BER6,2),'k-o');
xlabel('SNR');
ylabel('BER');
title('BER of 16QAM OFDM symbols after AWGN, rayleigh and Rice channel');
legend('AWGN-Subband1','AWGN-Subband2','rayleigh-Subband1','rayleigh-Subband2','Rice(k=2.8)-Subband1','Rice(k=2.8)-Subband2');
%% different modulations comparison
SNR=-5:3:16;
rep = 100;
BER = zeros(size(SNR,2),rep); %ber是一个8*10000的数组，每一列是一次实验出来的ber
BER2 = zeros(size(SNR,2),rep);
BER3 = zeros(size(SNR,2),rep);
BER4 = zeros(size(SNR,2),rep);
BER5 = zeros(size(SNR,2),rep);
BER6 = zeros(size(SNR,2),rep);
for j = 1:rep
    waitbar(j/rep); 
    [k1,m1] = F_OFDM_BCH_2BER(4,2,1,16,2.8,2048,0.01);
    BER(:,j) = k1'; %OFDM函数做出来的是一个1*8的数组
    BER2(:,j) = m1';
    [k2,m2] = F_OFDM_BCH_2BER(16,2,1,16,2.8,2048,0.01);
    BER3(:,j) = k2'; %OFDM函数做出来的是一个1*8的数组
    BER4(:,j) = m2';
    [k3,m3] = F_OFDM_BCH_2BER(64,2,1,16,2.8,2048,0.01);
    BER5(:,j) = k3'; %OFDM函数做出来的是一个1*8的数组
    BER6(:,j) = m3';
end

semilogy(SNR,mean(BER,2),'b-*');
hold on;
semilogy(SNR,mean(BER2,2),'b-o');
hold on;
semilogy(SNR,mean(BER3,2),'r-*');
hold on;
semilogy(SNR,mean(BER4,2),'r-o');
hold on;
semilogy(SNR,mean(BER5,2),'k-*');
hold on;
semilogy(SNR,mean(BER6,2),'k-o');
xlabel('SNR');
ylabel('BER');
title('BER of QPSK, 16QAM and 64QAM OFDM symbols after rayleigh channel');
legend('QPSK-Subband1','QPSK-Subband2','16QAM-Subband1','16QAM-Subband2','64QAM-Subband1','64QAM-Subband2');
%% different filter orders comparison
SNR=-5:3:16;
rep = 100;
BER = zeros(size(SNR,2),rep); %ber是一个8*10000的数组，每一列是一次实验出来的ber
BER2 = zeros(size(SNR,2),rep);
BER3 = zeros(size(SNR,2),rep);
BER4 = zeros(size(SNR,2),rep);
BER5 = zeros(size(SNR,2),rep);
BER6 = zeros(size(SNR,2),rep);
for j = 1:rep
    waitbar(j/rep); 
    [k1,m1] = F_OFDM_BCH_2BER(16,2,1,16,2.8,128,0.01);
    BER(:,j) = k1'; %OFDM函数做出来的是一个1*8的数组
    BER2(:,j) = m1';
    [k2,m2] = F_OFDM_BCH_2BER(16,2,1,16,2.8,512,0.01);
    BER3(:,j) = k2'; %OFDM函数做出来的是一个1*8的数组
    BER4(:,j) = m2';
    [k3,m3] = F_OFDM_BCH_2BER(16,2,1,16,2.8,2048,0.01);
    BER5(:,j) = k3'; %OFDM函数做出来的是一个1*8的数组
    BER6(:,j) = m3';
end

semilogy(SNR,mean(BER,2),'b-*');
hold on;
semilogy(SNR,mean(BER2,2),'b-o');
hold on;
semilogy(SNR,mean(BER3,2),'r-*');
hold on;
semilogy(SNR,mean(BER4,2),'r-o');
hold on;
semilogy(SNR,mean(BER5,2),'k-*');
hold on;
semilogy(SNR,mean(BER6,2),'k-o');
xlabel('SNR');
ylabel('BER');
title('BER of 16QAM OFDM symbols after 128, 512 and 2048 orders filters');
legend('128orders-Subband1','128orders-Subband2','512orders-Subband1','512orders-Subband2','2048orders-Subband1','2048orders-Subband2');
%% different PM filter weights comparison
SNR=-5:3:16;
rep = 100;
BER = zeros(size(SNR,2),rep); %ber是一个8*10000的数组，每一列是一次实验出来的ber
BER2 = zeros(size(SNR,2),rep);
BER3 = zeros(size(SNR,2),rep);
BER4 = zeros(size(SNR,2),rep);
BER5 = zeros(size(SNR,2),rep);
BER6 = zeros(size(SNR,2),rep);
for j = 1:rep
    waitbar(j/rep); 
    [k1,m1] = F_OFDM_BCH_2BER(16,2,1,16,2.8,2048,0.01);
    BER(:,j) = k1'; %OFDM函数做出来的是一个1*8的数组
    BER2(:,j) = m1';
    [k2,m2] = F_OFDM_BCH_2BER(16,2,1,16,2.8,2048,1);
    BER3(:,j) = k2'; %OFDM函数做出来的是一个1*8的数组
    BER4(:,j) = m2';
    [k3,m3] = F_OFDM_BCH_2BER(16,2,1,16,2.8,2048,100);
    BER5(:,j) = k3'; %OFDM函数做出来的是一个1*8的数组
    BER6(:,j) = m3';
end

semilogy(SNR,mean(BER,2),'b-*');
hold on;
semilogy(SNR,mean(BER2,2),'b-o');
hold on;
semilogy(SNR,mean(BER3,2),'r-*');
hold on;
semilogy(SNR,mean(BER4,2),'r-o');
hold on;
semilogy(SNR,mean(BER5,2),'k-*');
hold on;
semilogy(SNR,mean(BER6,2),'k-o');
xlabel('SNR');
ylabel('BER');
title('BER of 16QAM OFDM symbols after weights of 0.01, 1 and 100 pass-stop ratios filters');
legend('Eta=0.01-Subband1','Eta=0.01-Subband2','Eta=1-Subband1','Eta=1-Subband2','Eta=100-Subband1','Eta=100-Subband2');
%% comparison between OFDM and F-OFDM
SNR=-5:3:16;
rep = 100;
BER = zeros(size(SNR,2),rep); %ber是一个8*10000的数组，每一列是一次实验出来的ber
BER2 = zeros(size(SNR,2),rep);
BER3 = zeros(size(SNR,2),rep);
BER4 = zeros(size(SNR,2),rep);
BER5 = zeros(size(SNR,2),rep);
BER6 = zeros(size(SNR,2),rep);
BER7 = zeros(size(SNR,2),rep);
BER8 = zeros(size(SNR,2),rep);
BER9 = zeros(size(SNR,2),rep);
BER10 = zeros(size(SNR,2),rep);
BER11= zeros(size(SNR,2),rep);
BER12 = zeros(size(SNR,2),rep);
for j = 1:rep
    waitbar(j/rep); 
    [k1,m1] = F_OFDM_BCH_2BER(4,2,1,16,2.8,2048,0.01);
    BER(:,j) = k1'; %OFDM函数做出来的是一个1*8的数组
    BER2(:,j) = m1';
    [k2,m2] = F_OFDM_BCH_2BER(16,2,1,16,2.8,2048,0.01);
    BER3(:,j) = k2'; %OFDM函数做出来的是一个1*8的数组
    BER4(:,j) = m2';
    [k3,m3] = F_OFDM_BCH_2BER(64,2,1,16,2.8,2048,0.01);
    BER5(:,j) = k3'; %OFDM函数做出来的是一个1*8的数组
    BER6(:,j) = m3';

    [k4,m4] = OFDM_BCH_2BER(4,2,2.8);
    BER7(:,j) = k4'; %OFDM函数做出来的是一个1*8的数组
    BER8(:,j) = m4';
    [k5,m5] = OFDM_BCH_2BER(16,2,2.8);
    BER9(:,j) = k5'; %OFDM函数做出来的是一个1*8的数组
    BER10(:,j) = m5';
    [k6,m6] = OFDM_BCH_2BER(64,2,2.8);
    BER11(:,j) = k6'; %OFDM函数做出来的是一个1*8的数组
    BER12(:,j) = m6';
end

semilogy(SNR,mean(BER,2),'b-*');
hold on;
semilogy(SNR,mean(BER2,2),'b-o');
hold on;
semilogy(SNR,mean(BER3,2),'r-*');
hold on;
semilogy(SNR,mean(BER4,2),'r-o');
hold on;
semilogy(SNR,mean(BER5,2),'k-*');
hold on;
semilogy(SNR,mean(BER6,2),'k-o');
hold on;

semilogy(SNR,mean(BER7,2),'b--*');
hold on;
semilogy(SNR,mean(BER8,2),'b--o');
hold on;
semilogy(SNR,mean(BER9,2),'r--*');
hold on;
semilogy(SNR,mean(BER10,2),'r--o');
hold on;
semilogy(SNR,mean(BER11,2),'k--*');
hold on;
semilogy(SNR,mean(BER12,2),'k--o');

xlabel('SNR');
ylabel('BER');
title('BER of QPSK, 16QAM, 64QAM F-OFDM and OFDM symbols after rayleigh channels');
legend('F-OFDM-QPSK-Subband1','F-OFDM-QPSK-Subband2','F-OFDM-16QAM-Subband1','F-OFDM-16QAM-Subband2' ...
    ,'F-OFDM-64QAM-Subband1','F-OFDM-64QAM-Subband2' ...
    ,'OFDM-QPSK-Subband1','OFDM-QPSK-Subband2','OFDM-16QAM-Subband1','OFDM-16QAM-Subband2' ...
    ,'OFDM-64QAM-Subband1','F-OFDM-64QAM-Subband2');