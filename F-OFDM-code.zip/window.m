function [H] = window(h,type,beta)
%%加不同类型的窗
%模式：0 不加  1 汉宁 2汉明 3 凯泽
switch type 
    case 0
        H=h;
    case 1
        H=h.*hanning(length(h))';
    case 2
        H=h.*hamming(length(h))';
    case 3
        H=h.*kaiser(length(h),beta)';
end
