function [filter1] = mine_filter_new(fpass,fstop,N,Eta)

% All frequency values are in kHz.
Fs = 30720;  % Sampling Frequency

Fstop = fstop;           % Stopband Frequency
Fpass = fpass;           % Passband Frequency

% N = 2048; %阶数，可以自己设定
Wpass = 1;%阻带权重决定了滤波器在阻带内衰减的程度，即阻带内允许的误差
Wstop = Wpass * Eta; %通带和阻带的相对权重，通带权重决定了滤波器在通带内允许的误差（即通带波动）的重要性

b = firpm(N,[0 Fstop Fpass Fs/2]/(Fs/2), ...
    [0 0 1 1],[Wstop Wpass]);

Hd = dfilt.dffir(b);
filter1=Hd.Numerator;

end