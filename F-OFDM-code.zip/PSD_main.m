fs=30.72e3;%kHz
numFFT=[2048 1024];
M=16; %16QAM
N = 128; %Filter order
N1 = 0; % protective bandwidth
N2 = 1; % protective bandwidth
Eta = 0.005; %Weight Coefficient
numRBs = 50;             % Number of resource blocks
numSym = [14 25];
rbSize = [12 6];             % Number of subcarriers per resource block
cpLen = [160 144 ;224 200];              % Cyclic prefix length in samples
 bitsPerSubCarrier = log2(M); % 2: QPSK, 4: 16QAM, 6: 64QAM, 8: 256QAM
 
numDataCarriers =  numRBs*rbSize;
bitsIn1 = randi([0 1], bitsPerSubCarrier*numDataCarriers(1), numSym(1));
%modulation
symbolsIn1 = qammod(bitsIn1, 2^bitsPerSubCarrier, 'InputType', 'bit', ...
    'UnitAveragePower', true);
% Pack data into an OFDM symbol
offset = (numFFT-numDataCarriers)/2; % for band center
symbolsInOFDM1 = [zeros(offset(1),numSym(1)); symbolsIn1; ...
    zeros(numFFT(1)-offset(1)-numDataCarriers(1),numSym(1))];
ifftOut1 = ifft(symbolsInOFDM1);
 
% Prepend cyclic prefix
%subband1
temp1=[[ifftOut1(:,1)],[ifftOut1(:,8)]];
sig1=[temp1(end-cpLen(1,1)+1:end,:);temp1];
temp2=[[ifftOut1(:,2:7)],[ifftOut1(:,9:14)]];
sig2=[temp2(end-cpLen(1,2)+1:end,:);temp2];
txsig1=[sig1(:,1);reshape(sig2(:,1:6),6*2192,1);sig1(:,2);reshape(sig2(:,7:12),6*2192,1)];
 
%子带滤波器
h=mine_filter_new(10860,10860-N1*15-N2*30,N,Eta);
%加窗
beta=16;
h1=window(h,1,beta);
h2=window(h,2,beta);
h3=window(h,3,beta);
halflen=floor(length(h)/2);
sigFil1=upfirdn(txsig1,h1,1); 
sigFil1=sigFil1(halflen+1:30720+halflen);
sigFil2=upfirdn(txsig1,h2,1); 
sigFil2=sigFil2(halflen+1:30720+halflen);
sigFil3=upfirdn(txsig1,h3,1); 
sigFil3=sigFil3(halflen+1:30720+halflen);


%[psd,f] = periodogram(txsig1, rectwin(length(sigFil0)), ...
%    numFFT(1)*2, 1);
[psd,f] = periodogram(txsig1);
[psd1,f1] = periodogram(sigFil1);
[psd2,f2] = periodogram(sigFil2);
[psd3,f3] = periodogram(sigFil3);

subplot(2,2,1);
plot(f,10*log10(psd));
hold on 
plot(f1,10*log10(psd1));
title('16QAM调制下加窗前后信号的psd')
xlabel('Normalized Frequency(xΠ)')
ylabel('gain(dB)')
legend('加窗前','加汉宁窗后')
%[psd,f] = periodogram(sigFil1, rectwin(length(sigFil1)), ...
%    numFFT(1)*2, 1);



subplot(2,2,2);plot(f,10*log10(psd));
hold on 
plot(f2,10*log10(psd2));
title('16QAM调制下加窗前后信号的psd')
xlabel('Normalized Frequency(xΠ)')
ylabel('gain(dB)')
legend('加窗前','加汉明窗后')



subplot(2,2,3);plot(f,10*log10(psd));
hold on 
plot(f3,10*log10(psd3));
title('16QAM调制下加窗前后信号的psd')
xlabel('Normalized Frequency(xΠ)')
ylabel('gain(dB)')
legend('加窗前','加凯泽窗后')
