function [sigOut] = channel(sigIn,mode,snr,k)
switch mode
    case 1 %AWGN信道
        sigOut = awgn(sigIn,snr, 'measured');
    case 2 %瑞利信道
        SNR_linear = 10^(snr/10);
        size_sig=size(sigIn);
        Ray=(randn(size_sig) + 1i*randn(size_sig));
        sig=sigIn.*Ray;
        sig=awgn(sig,snr,'measured');
        % sigOut=sig./Ray;
        sigOut = (conj(Ray) ./ (abs(Ray).^2 + 1/SNR_linear)).*sig;
    case 3 %莱斯信道
        SNR_linear = 10^(snr/10);
        K=k;  
        A=sqrt(K*2);
        size_sig=size(sigIn);
        Rice=A*exp(1i*2*pi*rand(1))+randn(size_sig)+1i*randn(size_sig);
        sig=sigIn.*Rice;
        sig=awgn(sig,snr,'measured');
        % sigOut=sig./Rice;
        sigOut = (conj(Rice) ./ (abs(Rice).^2 + 1/SNR_linear)).*sig;
end
 
end
