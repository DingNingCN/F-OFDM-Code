function [BER] = OFDM_BCH(M,channeltype,k) %这个k是莱斯信道专用的因子
%% 参数设计
%fft窗口
fs=30.72e3;%kHz
numFFT=[2048 1024];
 
numRBs = 50;             % Number of resource blocks
numSym = [14 25];
rbSize = [12 6];             % Number of subcarriers per resource block
cpLen = [160 144 ;224 200];              % Cyclic prefix length in samples
bitsPerSubCarrier = log2(M); % 2: QPSK, 4: 16QAM, 6: 64QAM, 8: 256QAM

enc = comm.BCHEncoder;
dec = comm.BCHDecoder;



input_bits1 = randi([0, 1], 4800, 1);
input_bits2 = randi([0, 1], 4800, 1);

%bits_encode1 = lteTurboEncode(input_bits1); %14412 * 1的列向量
%bits_encode2 = lteTurboEncode(input_bits2); %14412 * 1的列向量
bits_encode1 = enc(input_bits1);
bits_encode2 = enc(input_bits2);

num_bits_encode1 = length(bits_encode1); %14412
num_bits_encode2 = length(bits_encode2); %14412
disp(size(bits_encode1));

target_bits_length1 = bitsPerSubCarrier*600*14;  %最小都是2*8400，一定会大于14412
target_bits_length2 = bitsPerSubCarrier*300*25;  %最小都是2*7500，一定会大于14412

bits_padding1 = [];
if num_bits_encode1 < target_bits_length1
    bits_padding1 = [bits_encode1; zeros(target_bits_length1 - num_bits_encode1, 1)];
end

bits_padding2 = [];
if num_bits_encode2 < target_bits_length2
    bits_padding2 = [bits_encode2; zeros(target_bits_length2 - num_bits_encode2, 1)];
end

% num_symbols1 = length(bits_encode1)/bitsPerSubCarrier;

numDataCarriers =  numRBs*rbSize; %600和300

bitsIn1 = reshape(bits_padding1, bitsPerSubCarrier*numDataCarriers(1), numSym(1));
% bitsIn1 = randi([0 1], bitsPerSubCarrier*numDataCarriers(1), numSym(1));
bitsIn2 = reshape(bits_padding2, bitsPerSubCarrier*numDataCarriers(2), numSym(2));
% bitsIn2 = randi([0 1], bitsPerSubCarrier*numDataCarriers(2), numSym(2));
%modulation
symbolsIn1 = qammod(bitsIn1, 2^bitsPerSubCarrier, 'InputType', 'bit', ...
    'UnitAveragePower', true);
symbolsIn2 = qammod(bitsIn2, 2^bitsPerSubCarrier, 'InputType', 'bit', ...
    'UnitAveragePower', true);
% Pack data into an OFDM symbol
offset = (numFFT-numDataCarriers)/2; % for band center
symbolsInOFDM1 = [zeros(offset(1),numSym(1)); symbolsIn1; ...
    zeros(numFFT(1)-offset(1)-numDataCarriers(1),numSym(1))];
symbolsInOFDM2 = [zeros(offset(2),numSym(2)); symbolsIn2; ...
    zeros(numFFT(2)-offset(2)-numDataCarriers(2),numSym(2))];
ifftOut1 = ifft(symbolsInOFDM1);
ifftOut2 = ifft(symbolsInOFDM2);
 
% Prepend cyclic prefix
%subband1
temp1=[[ifftOut1(:,1)],[ifftOut1(:,8)]];
sig1=[temp1(end-cpLen(1,1)+1:end,:);temp1];
temp2=[[ifftOut1(:,2:7)],[ifftOut1(:,9:14)]];
sig2=[temp2(end-cpLen(1,2)+1:end,:);temp2];
txsig1=[sig1(:,1);reshape(sig2(:,1:6),6*2192,1);sig1(:,2);reshape(sig2(:,7:12),6*2192,1)];
 
%subband2
txsig2=[];
for i=0:4
    temp1=ifftOut2(:,5*i+1);
    sig1=[temp1(end-cpLen(2,1)+1:end,:);temp1];
    temp2=ifftOut2(:,5*i+2:5*i+5);
    sig2=[temp2(end-cpLen(2,2)+1:end,:);temp2];
    txsig2=[txsig2;[sig1;reshape(sig2(:,1:4),4*1224,1)]];      
end


%加载波
fc1=0;fc2=9045;
t=0:1/fs:(1-1/fs);
Tx=txsig1.*exp(j*2*pi*fc1*t')+txsig2.*exp(j*2*pi*fc2*t');
%过信道
snr=-5:3:16;
 for m=1:length(snr)    
    [Rx_channel] = channel(Tx,channeltype,snr(m),k);
    %下变频
    Rxsig1=Rx_channel.*exp(-j*2*pi*fc1*t');
    Rxsig2=Rx_channel.*exp(-j*2*pi*fc2*t');
    %去cp
    %subband1
    for i=1:14
        if i==1||i==8
            Rxsig1(1:160)=[]; % 这行代码直接可以把一个30720*1的列向量的前160行去掉变成一个30560*1的列向量
            Rx_nocp1(:,i)=Rxsig1(1:2048);
            Rxsig1(1:2048)=[]; % 把有用位置的2048个变量给到Rx_nocp1之后，可以删掉这2048个变量了
        else
            Rxsig1(1:144)=[];
            Rx_nocp1(:,i)=Rxsig1(1:2048);
            Rxsig1(1:2048)=[];
        end
    end
    %subband2
    for i=1:25
        if mod(i,5)==1
            Rxsig2(1:224)=[];
            Rx_nocp2(:,i)=Rxsig2(1:1024);
            Rxsig2(1:1024)=[];
        else
            Rxsig2(1:200)=[];
            Rx_nocp2(:,i)=Rxsig2(1:1024);
            Rxsig2(1:1024)=[];
        end
    end
 
    RxSymbols1 = fft(Rx_nocp1);%FFT
    RxSymbols2 = fft(Rx_nocp2);%FFT
    % Select data subcarriers
    dataRxSymbols1 = RxSymbols1(offset(1)+(1:numDataCarriers(1)),:);
    dataRxSymbols2 = RxSymbols2(offset(2)+(1:numDataCarriers(2)),:);
    rxBits1 = qamdemod(dataRxSymbols1, 2^bitsPerSubCarrier, 'OutputType', 'bit', ...
        'UnitAveragePower', true);
    rxBits2 = qamdemod(dataRxSymbols2, 2^bitsPerSubCarrier, 'OutputType', 'bit', ...
        'UnitAveragePower', true);
    

    size1 = size(rxBits1);
    size2 = size(rxBits2);
    rxBits1 = reshape(rxBits1,size1(1)*size1(2),1);
    rxBits2 = reshape(rxBits2,size2(1)*size2(2),1);

    
    %去掉padding
    rxBits1 = rxBits1(1:num_bits_encode1);
    % disp(size(rxBits1));
    rxBits2 = rxBits2(1:num_bits_encode2);

    %rxBits1_decode = lteTurboDecode(rxBits1);
    %rxBits2_decode = lteTurboDecode(rxBits2);
    rxBits1_decode = dec(rxBits1);
    rxBits2_decode = dec(rxBits2);

    [errors1 ber1(m)]= biterr(input_bits1,rxBits1_decode);
    [errors2 ber2(m)]= biterr(input_bits2,rxBits2_decode);
    % BER(m)= (ber1(m)*28+ber2(m)*25)/53;
    % BER(m)= (ber1(m)*size1(1)*size1(2)+ber2(m)*size2(1)*size2(2))/(size1(1)*size1(2)+size2(1)*size2(2));
    BER(m)= (ber1(m)+ber2(m))/2;
 end %这个end和上面的for m = 1 to length（snr）是一组
end
