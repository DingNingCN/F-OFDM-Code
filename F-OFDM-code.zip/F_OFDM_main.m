%% different windows comparison
SNR=-5:3:16;
rep = 100;
BER = zeros(size(SNR,2),rep); %ber是一个8*10000的数组，每一列是一次实验出来的ber
BER2 = zeros(size(SNR,2),rep);
BER3 = zeros(size(SNR,2),rep);
for j = 1:rep
    waitbar(j/rep); 
    [BER(:,j)] = (F_OFDM_BCH(16,2,1,16,2.8,2048,0.01))'; %F_OFDM_BCH函数做出来的是一个1*8的数组
    [BER2(:,j)] = (F_OFDM_BCH(16,2,2,16,2.8,2048,0.01))';
    [BER3(:,j)] = (F_OFDM_BCH(16,2,3,16,2.8,2048,0.01))';
end

semilogy(SNR,mean(BER,2),'b-*');
hold on;
semilogy(SNR,mean(BER2,2),'r-*');
hold on;
semilogy(SNR,mean(BER3,2),'k-*');
xlabel('SNR');
ylabel('BER');
title('BER of 16QAM OFDM symbols under different windows after rayleigh channel');
legend('hanning','hamming','kaiser(beta=16)');

%% different channels comparison
SNR=-5:3:16;
rep = 100;
BER = zeros(size(SNR,2),rep); %ber是一个8*10000的数组，每一列是一次实验出来的ber
BER2 = zeros(size(SNR,2),rep);
BER3 = zeros(size(SNR,2),rep);
for j = 1:rep
    waitbar(j/rep); 
    [BER(:,j)] = (F_OFDM_BCH(16,1,1,16,2.8,2048,0.01))'; %F_OFDM_BCH函数做出来的是一个1*8的数组
    [BER2(:,j)] = (F_OFDM_BCH(16,2,1,16,2.8,2048,0.01))';
    [BER3(:,j)] = (F_OFDM_BCH(16,3,1,16,2.8,2048,0.01))';
end

semilogy(SNR,mean(BER,2),'b-*');
hold on;
semilogy(SNR,mean(BER2,2),'r-*');
hold on;
semilogy(SNR,mean(BER3,2),'k-*');
xlabel('SNR');
ylabel('BER');
title('BER of 16QAM OFDM symbols after AWGN, rayleigh and Rice channel');
legend('AWGN','rayleigh','Rice(k=2.8)');


%% different modulations comparison
SNR=-5:3:16;
rep = 100;
BER = zeros(size(SNR,2),rep); %ber是一个8*10000的数组，每一列是一次实验出来的ber
BER2 = zeros(size(SNR,2),rep);
BER3 = zeros(size(SNR,2),rep);
for j = 1:rep
    waitbar(j/rep); 
    [BER(:,j)] = (F_OFDM_BCH(4,2,1,16,2.8,2048,0.01))'; %F_OFDM_BCH函数做出来的是一个1*8的数组
    [BER2(:,j)] = (F_OFDM_BCH(16,2,1,16,2.8,2048,0.01))';
    [BER3(:,j)] = (F_OFDM_BCH(64,2,1,16,2.8,2048,0.01))';
end

semilogy(SNR,mean(BER,2),'b-*');
hold on;
semilogy(SNR,mean(BER2,2),'r-*');
hold on;
semilogy(SNR,mean(BER3,2),'k-*');
xlabel('SNR');
ylabel('BER');
title('BER of QPSK, 16QAM and 64QAM OFDM symbols after rayleigh channel');
legend('QPSK','16QAM','64QAM');

%% different filter orders comparison
SNR=-5:3:16;
rep = 100;
BER = zeros(size(SNR,2),rep); %ber是一个8*10000的数组，每一列是一次实验出来的ber
BER2 = zeros(size(SNR,2),rep);
BER3 = zeros(size(SNR,2),rep);
for j = 1:rep
    waitbar(j/rep); 
    [BER(:,j)] = (F_OFDM_BCH(16,2,1,16,2.8,128,0.01))'; %F_OFDM_BCH函数做出来的是一个1*8的数组
    [BER2(:,j)] = (F_OFDM_BCH(16,2,1,16,2.8,512,0.01))';
    [BER3(:,j)] = (F_OFDM_BCH(16,2,1,16,2.8,2048,0.01))';
end

semilogy(SNR,mean(BER,2),'b-*');
hold on;
semilogy(SNR,mean(BER2,2),'r-*');
hold on;
semilogy(SNR,mean(BER3,2),'k-*');
xlabel('SNR');
ylabel('BER');
title('BER of 16QAM OFDM symbols after 128, 512 and 2048 orders filters');
legend('128','512','2048');

%% different PM filter weights comparison
SNR=-5:3:16;
rep = 100;
BER = zeros(size(SNR,2),rep); %ber是一个8*10000的数组，每一列是一次实验出来的ber
BER2 = zeros(size(SNR,2),rep);
BER3 = zeros(size(SNR,2),rep);
for j = 1:rep
    waitbar(j/rep); 
    [BER(:,j)] = (F_OFDM_BCH(16,2,1,16,2.8,2048,0.01))'; %F_OFDM_BCH函数做出来的是一个1*8的数组
    [BER2(:,j)] = (F_OFDM_BCH(16,2,1,16,2.8,2048,1))';
    [BER3(:,j)] = (F_OFDM_BCH(16,2,1,16,2.8,2048,100))';
end

semilogy(SNR,mean(BER,2),'b-*');
hold on;
semilogy(SNR,mean(BER2,2),'r-*');
hold on;
semilogy(SNR,mean(BER3,2),'k-*');
xlabel('SNR');
ylabel('BER');
title('BER of 16QAM OFDM symbols after weights of 0.01, 1 and 100 pass-stop ratios filters');
legend('Eta=0.01','Eta=1','Eta=100');
%% comparison between OFDM and F-OFDM
% 不同保护频带时OFDM与F-OFDM的差别,N1=1,N2=0,F0=9030,因此下面这段代码要把函数里的f0从9045改成9030，且把N1改为1，N2改为0再run，这是因为
% 这样可以更加凸显两者的差别，如果保护频带设太大了就不太好，当然不想改的话也可以，就保持N1=0，N2=1,F0=9045只是这样两者差别没那么明显了
SNR=-5:3:16;
rep = 100;
BER = zeros(size(SNR,2),rep); %ber是一个8*10000的数组，每一列是一次实验出来的ber
BER2 = zeros(size(SNR,2),rep);
BER3 = zeros(size(SNR,2),rep);
BER4 = zeros(size(SNR,2),rep);
BER5 = zeros(size(SNR,2),rep);
BER6 = zeros(size(SNR,2),rep);
for j = 1:rep
    waitbar(j/rep); 
    [BER(:,j)] = (F_OFDM_BCH(4,2,1,16,2.8,2048,0.01))'; %F_OFDM_BCH函数做出来的是一个1*8的数组
    [BER2(:,j)] = (OFDM_BCH(4,2,2.8))';
    [BER3(:,j)] = (F_OFDM_BCH(16,2,1,16,2.8,2048,0.01))'; %F_OFDM_BCH函数做出来的是一个1*8的数组
    [BER4(:,j)] = (OFDM_BCH(16,2,2.8))';
    [BER5(:,j)] = (F_OFDM_BCH(64,2,1,16,2.8,2048,0.01))'; %F_OFDM_BCH函数做出来的是一个1*8的数组
    [BER6(:,j)] = (OFDM_BCH(64,2,2.8))';
end

semilogy(SNR,mean(BER,2),'b-*');
hold on;
semilogy(SNR,mean(BER2,2),'b-o');
hold on;
semilogy(SNR,mean(BER3,2),'r-*');
hold on;
semilogy(SNR,mean(BER4,2),'r-o');
hold on;
semilogy(SNR,mean(BER5,2),'k-*');
hold on;
semilogy(SNR,mean(BER6,2),'k-o');
xlabel('SNR');
ylabel('BER');
title('BER of QPSK, 16QAM, 64QAM F-OFDM and OFDM symbols after rayleigh channels');
legend('F-OFDM-QPSK','OFDM-QPSK','F-OFDM-16QAM','OFDM-16QAM','F-OFDM-64QAM','OFDM-64QAM');